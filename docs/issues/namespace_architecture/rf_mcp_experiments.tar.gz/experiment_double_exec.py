"""
Experiment 2: Does the rf-mcp approach cause double execution?
Test the runner.run() + StatusReporter interaction.
"""
import sys, os, tempfile

from robot.running.context import EXECUTION_CONTEXTS
from robot.running.namespace import Namespace
from robot.variables.scopes import VariableScopes
from robot.output import Output
from robot.running.model import TestSuite, TestCase as RunTest, Keyword as RunKeyword
from robot.result.model import TestSuite as ResultSuite, TestCase as ResTest, Keyword as ResultKeyword
from robot.conf import Languages, RobotSettings

call_count = 0

def setup_native_context():
    """Set up a proper RF context (native ordering)."""
    variables = VariableScopes(RobotSettings())
    suite = TestSuite(name="Test")
    
    temp_dir = tempfile.mkdtemp(prefix="rf_exp_")
    settings = RobotSettings(outputdir=temp_dir, output=None, console='none')
    output = Output(settings)
    try:
        output.library_listeners.new_suite_scope()
    except:
        pass
    
    result_suite = ResultSuite(name=suite.name, source=suite.source)
    namespace = Namespace(variables, result_suite, suite.resource, Languages())
    namespace.start_suite()
    namespace.variables.set_from_variable_section(suite.resource.variables)
    ctx = EXECUTION_CONTEXTS.start_suite(result_suite, namespace, output, dry_run=False)
    ctx.set_suite_variables(result_suite)
    namespace.handle_imports()
    namespace.variables.resolve_delayed()
    
    # Import Collections for testing
    namespace.import_library("Collections")
    
    # Start test
    namespace.start_test()
    run_test = RunTest(name="Test")
    res_test = ResTest(name="Test")
    ctx.start_test(run_test, res_test)
    
    return ctx, namespace, variables, res_test


def test_runner_run_directly():
    """Test: Does runner.run() handle assignment correctly?"""
    print("\n=== Test: runner.run() with assign ===")
    ctx, namespace, variables, res_test = setup_native_context()
    
    try:
        # Get the runner for Create List
        runner = namespace.get_runner("Create List")
        
        # Build keyword models WITH assignment
        data_kw = RunKeyword(
            name="Create List", 
            args=("a", "b", "c"),
            assign=("${mylist}",)
        )
        res_kw = ResultKeyword(name="Create List")
        res_kw.parent = res_test
        
        result = runner.run(data_kw, res_kw, ctx)
        print(f"  runner.run() returned: {result}")
        
        # Check if RF assigned the variable
        try:
            val = variables["${mylist}"]
            print(f"  ${{mylist}} in RF variables: {val} ✓")
        except:
            print(f"  ${{mylist}} NOT in RF variables (runner.run doesn't assign?)")
        
        # Now also manually assign like rf-mcp does
        variables["${mylist_manual}"] = result
        val2 = variables["${mylist_manual}"]
        print(f"  Manual assignment: ${{mylist_manual}} = {val2}")
        
    except Exception as e:
        print(f"  FAILED: {e}")
        import traceback; traceback.print_exc()
    finally:
        EXECUTION_CONTEXTS.end_suite()


def test_double_execution_paths():
    """Test: Does rf-mcp's generic → outer fallback cause double execution?"""
    print("\n=== Test: Double execution detection ===")
    ctx, namespace, variables, res_test = setup_native_context()
    
    try:
        from robot.libraries.BuiltIn import BuiltIn
        
        # Track what happens with Set Suite Variable
        # In rf-mcp, _execute_any_keyword_generic first tries runner.run()
        # If that fails, _execute_with_native_resolution tries runner.run() AGAIN
        
        # Let's trace: if runner.run() works in generic path,
        # does it get called again?
        
        # Simulate rf-mcp's _execute_any_keyword_generic
        keyword_name = "Create List"
        arguments = ["x", "y"]
        
        runner = namespace.get_runner(keyword_name)
        data_kw = RunKeyword(name=keyword_name, args=tuple(arguments))
        res_kw = ResultKeyword(name=keyword_name, args=tuple(arguments))
        res_kw.parent = res_test  # Need parent for StatusReporter
        
        # This is what rf-mcp does in _execute_any_keyword_generic line 634
        result1 = runner.run(data_kw, res_kw, ctx)
        print(f"  First runner.run() result: {result1}")
        
        # If the generic path succeeds, rf-mcp returns immediately
        # (line 860-866). The outer runner.run at line 984 is only reached
        # if the generic path raises a non-ExecutionStatus exception.
        # So there's no ACTUAL double execution if the first call works.
        print(f"  No double execution if generic path succeeds ✓")
        
        # BUT: the generic path has 3 fallbacks:
        # 1. namespace.get_runner() + runner.run()   
        # 2. direct method lookup (bypasses RF!)
        # 3. BuiltIn.run_keyword()
        # If #1 fails with non-ExecutionStatus, it tries #2 and #3
        
    except Exception as e:
        print(f"  FAILED: {e}")
        import traceback; traceback.print_exc()
    finally:
        EXECUTION_CONTEXTS.end_suite()


def test_direct_method_bypass():
    """Test: Does direct method call bypass RF argument resolution?"""
    print("\n=== Test: Direct method call bypass ===")
    ctx, namespace, variables, res_test = setup_native_context()
    
    try:
        # Set a variable first
        variables["${name}"] = "World"
        
        # Test 1: Through RF runner (proper way)
        from robot.libraries.BuiltIn import BuiltIn
        bi = BuiltIn()
        result_proper = bi.run_keyword("Set Variable", "Hello ${name}")
        print(f"  Via BuiltIn.run_keyword: '{result_proper}' (should be 'Hello World')")
        
        # Test 2: Direct method call (rf-mcp fallback)
        # This is what _try_execute_from_library does
        method = getattr(bi, 'set_variable')
        result_direct = method("Hello ${name}")
        print(f"  Via direct method call: '{result_direct}' (should be 'Hello ${{name}}' - NO resolution!)")
        
        # Test 3: With Collections
        from robot.libraries.Collections import Collections
        coll = Collections()
        
        # Proper way
        test_list = bi.run_keyword("Create List", "a", "b")
        result_proper2 = bi.run_keyword("Get Length", test_list)
        print(f"  Via BuiltIn.run_keyword Get Length: {result_proper2}")
        
        # Direct call - this works for simple cases but bypasses type conversion
        result_direct2 = coll.get_length(test_list)
        print(f"  Via direct method call Get Length: {result_direct2}")
        
    except Exception as e:
        print(f"  FAILED: {e}")
        import traceback; traceback.print_exc()
    finally:
        EXECUTION_CONTEXTS.end_suite()


def test_variable_scope_ordering():
    """Test: Does calling start_suite AFTER imports affect variable scoping?"""
    print("\n=== Test: Variable scope with rf-mcp ordering ===")
    
    # rf-mcp ordering: imports happen before start_suite
    variables = VariableScopes(RobotSettings())
    suite = TestSuite(name="Test")
    temp_dir = tempfile.mkdtemp(prefix="rf_exp_")
    settings = RobotSettings(outputdir=temp_dir, output=None, console='none')
    output = Output(settings)
    try:
        output.library_listeners.new_suite_scope()
    except:
        pass
    
    result_suite = ResultSuite(name=suite.name)
    namespace = Namespace(variables, result_suite, suite.resource, Languages())
    
    # Push context first (rf-mcp order)
    ctx = EXECUTION_CONTEXTS.start_suite(result_suite, namespace, output, dry_run=False)
    
    # Import libraries (context is active, so import_library works)
    namespace.handle_imports()  # BuiltIn + Easter
    namespace.import_library("Collections")
    print(f"  Libraries imported: {[lib.name for lib in namespace.libraries]}")
    
    # NOW call start_suite (after imports!)
    namespace.start_suite()
    print(f"  Scope depth after start_suite: {len(variables._scopes)}")
    
    # Start test
    namespace.start_test()
    run_test = RunTest(name="Test")
    res_test = ResTest(name="Test")
    ctx.start_test(run_test, res_test)
    
    # Test: can we use BuiltIn?
    from robot.libraries.BuiltIn import BuiltIn
    bi = BuiltIn()
    
    # Test variable isolation
    bi.run_keyword("Set Suite Variable", "${SUITE_V}", "suite_value")
    bi.run_keyword("Set Test Variable", "${TEST_V}", "test_value")
    
    suite_v = bi.get_variable_value("${SUITE_V}")
    test_v = bi.get_variable_value("${TEST_V}")
    print(f"  ${{SUITE_V}} = {suite_v}")
    print(f"  ${{TEST_V}} = {test_v}")
    
    # Verify suite variable persists after test scope pop
    # (end_test should clear test vars but keep suite vars)
    print(f"  Scope depth before end_test: {len(variables._scopes)}")
    
    EXECUTION_CONTEXTS.end_suite()
    print(f"  RESULT: PASS")


if __name__ == "__main__":
    test_runner_run_directly()
    test_double_execution_paths()
    test_direct_method_bypass()
    test_variable_scope_ordering()
