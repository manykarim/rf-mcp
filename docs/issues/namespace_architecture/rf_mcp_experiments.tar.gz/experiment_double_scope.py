"""
Experiment 5: Does rf-mcp's double namespace.start_suite/start_test cause scope issues?
rf-mcp calls: 
  1. namespace.start_suite() at line 341
  2. namespace.start_test() at line 342  
  3. ctx.start_test(run_test, res_test) at line 349
  
But ctx.start_test() ALSO calls namespace.start_test() internally!
"""
import sys, os, tempfile

from robot.running.context import EXECUTION_CONTEXTS
from robot.running.namespace import Namespace
from robot.variables.scopes import VariableScopes
from robot.output import Output
from robot.running.model import TestSuite, TestCase as RunTest
from robot.result.model import TestSuite as ResultSuite, TestCase as ResTest
from robot.conf import Languages, RobotSettings

def test_double_start_test():
    """Simulate rf-mcp's exact sequence and check scope depth."""
    print("=== Test: Double start_test scope accumulation ===")
    
    variables = VariableScopes(RobotSettings())
    suite = TestSuite(name="Test")
    temp_dir = tempfile.mkdtemp(prefix="rf_exp_")
    settings = RobotSettings(outputdir=temp_dir, output=None, console='none')
    output = Output(settings)
    try: output.library_listeners.new_suite_scope()
    except: pass
    result_suite = ResultSuite(name=suite.name)
    namespace = Namespace(variables, result_suite, suite.resource, Languages())
    
    # rf-mcp pushes context FIRST
    ctx = EXECUTION_CONTEXTS.start_suite(result_suite, namespace, output, dry_run=False)
    
    # Then imports
    namespace.handle_imports()
    
    print(f"  After context push:  scopes={len(variables._scopes)}")  # expect 1 (global only)
    
    # rf-mcp calls start_suite
    namespace.start_suite()
    print(f"  After ns.start_suite(): scopes={len(variables._scopes)}")  # expect 2
    
    # rf-mcp calls start_test
    namespace.start_test()
    print(f"  After ns.start_test(): scopes={len(variables._scopes)}")  # expect 3
    
    # rf-mcp ALSO calls ctx.start_test() which internally calls:
    #   self.namespace.start_test()  <- ANOTHER start_test!
    # Let's check context.py
    print(f"\n  Now calling ctx.start_test()...")
    run_test = RunTest(name="Test")
    res_test = ResTest(name="Test")
    ctx.start_test(run_test, res_test)
    print(f"  After ctx.start_test(): scopes={len(variables._scopes)}")  # expect 4 if doubled!
    
    # Compare with proper RF behavior
    print(f"\n  Expected scope chain: [global, suite, test] = 3 scopes")
    print(f"  Actual scope chain:  {len(variables._scopes)} scopes")
    if len(variables._scopes) > 3:
        print(f"  *** EXTRA SCOPES DETECTED! ***")
        print(f"  This means variables are looked up in the wrong scope.")
    
    # Check if ctx.start_test calls namespace.start_test
    import inspect
    src = inspect.getsource(ctx.start_test)
    has_ns_start_test = "namespace.start_test" in src
    print(f"\n  ctx.start_test() calls namespace.start_test(): {has_ns_start_test}")
    
    EXECUTION_CONTEXTS.end_suite()


def test_rfmcp_full_lifecycle_scopes():
    """Trace exact rf-mcp create_context_for_session scope changes."""
    print("\n=== Test: Full rf-mcp lifecycle scope trace ===")
    
    variables = VariableScopes(RobotSettings())
    suite = TestSuite(name="MCP_Session")
    temp_dir = tempfile.mkdtemp(prefix="rf_exp_")
    settings = RobotSettings(outputdir=temp_dir, output=None, console='none')
    output = Output(settings)
    try: output.library_listeners.new_suite_scope()
    except: pass
    result_suite = ResultSuite(name=suite.name)
    namespace = Namespace(variables, result_suite, suite.resource, Languages())
    
    print(f"  [init]                scopes={len(variables._scopes)}")
    
    # rf-mcp: import_library("BuiltIn") → calls _current_owner_and_lineno
    # which needs EXECUTION_CONTEXTS.current → fails if no context
    # BUT rf-mcp wraps this in try/except, so it may silently fail
    
    # rf-mcp: EXECUTION_CONTEXTS.start_suite(...)
    ctx = EXECUTION_CONTEXTS.start_suite(result_suite, namespace, output, dry_run=False)
    print(f"  [ctx.start_suite]     scopes={len(variables._scopes)}")
    
    # rf-mcp line 226: namespace.import_library("BuiltIn")  
    namespace.import_library("BuiltIn")
    print(f"  [import BuiltIn]      scopes={len(variables._scopes)}")
    
    # rf-mcp line 341: namespace.start_suite()
    namespace.start_suite()
    print(f"  [ns.start_suite()]    scopes={len(variables._scopes)}")
    
    # rf-mcp line 342: namespace.start_test()
    namespace.start_test()
    print(f"  [ns.start_test()]     scopes={len(variables._scopes)}")
    
    # rf-mcp line 349: ctx.start_test(run_test, res_test) 
    # ctx.start_test internally calls namespace.start_test() AGAIN
    run_test = RunTest(name="Test")
    res_test = ResTest(name="Test")
    ctx.start_test(run_test, res_test)
    print(f"  [ctx.start_test()]    scopes={len(variables._scopes)}")
    
    # Now test if keywords still work despite extra scopes
    from robot.libraries.BuiltIn import BuiltIn
    bi = BuiltIn()
    
    bi.run_keyword("Set Test Variable", "${X}", "hello")
    val = bi.get_variable_value("${X}")
    print(f"  Set Test Variable + get: val = {val}")
    
    # But what about scope isolation?
    # With an extra test scope, end_test pops only ONE level
    # The other test scope remains as a zombie
    
    # Let's verify by checking what end_test does
    print(f"\n  Before end_test: scopes={len(variables._scopes)}")
    
    # end_test pops one test scope
    ctx.end_test(res_test)
    print(f"  After ctx.end_test(): scopes={len(variables._scopes)}")
    
    # The ns.start_test() scope is still there as a zombie!
    # This means ${X} might still be visible when it shouldn't be
    try:
        val_after = variables["${X}"]
        print(f"  X still visible after end_test: {val_after} ZOMBIE SCOPE!")
    except:
        print(f"  X properly cleaned up after end_test")
    
    EXECUTION_CONTEXTS.end_suite()

def test_correct_lifecycle():
    """Show what the correct scope trace looks like."""
    print("\n=== Test: Correct RF lifecycle scope trace ===")
    
    variables = VariableScopes(RobotSettings())
    suite = TestSuite(name="Correct")
    temp_dir = tempfile.mkdtemp(prefix="rf_exp_")
    settings = RobotSettings(outputdir=temp_dir, output=None, console='none')
    output = Output(settings)
    try: output.library_listeners.new_suite_scope()
    except: pass
    result_suite = ResultSuite(name=suite.name)
    namespace = Namespace(variables, result_suite, suite.resource, Languages())
    
    print(f"  [init]                scopes={len(variables._scopes)}")
    
    namespace.start_suite()
    print(f"  [ns.start_suite()]    scopes={len(variables._scopes)}")
    
    namespace.variables.set_from_variable_section(suite.resource.variables)
    
    ctx = EXECUTION_CONTEXTS.start_suite(result_suite, namespace, output, dry_run=False)
    ctx.set_suite_variables(result_suite)
    print(f"  [ctx push + vars]     scopes={len(variables._scopes)}")
    
    namespace.handle_imports()
    namespace.variables.resolve_delayed()
    print(f"  [handle_imports]      scopes={len(variables._scopes)}")
    
    # Start test: ctx.start_test calls namespace.start_test internally
    run_test = RunTest(name="Test")
    res_test = ResTest(name="Test")
    ctx.start_test(run_test, res_test)
    print(f"  [ctx.start_test()]    scopes={len(variables._scopes)}")
    
    from robot.libraries.BuiltIn import BuiltIn
    bi = BuiltIn()
    bi.run_keyword("Set Test Variable", "${Y}", "world")
    
    print(f"  Before end_test: scopes={len(variables._scopes)}")
    ctx.end_test(res_test)
    print(f"  After end_test:  scopes={len(variables._scopes)}")
    
    try:
        variables["${Y}"]
        print(f"  Y still visible BAD")
    except:
        print(f"  Y properly cleaned")
    
    EXECUTION_CONTEXTS.end_suite()


if __name__ == "__main__":
    test_double_start_test()
    test_rfmcp_full_lifecycle_scopes()
    test_correct_lifecycle()
