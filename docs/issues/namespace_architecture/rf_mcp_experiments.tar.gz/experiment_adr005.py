"""
Experiment 6: ADR-005 start_test_in_context has the SAME double-call bug.
It calls namespace.start_test() AND ctx.start_test() separately.
"""
import tempfile
from robot.running.context import EXECUTION_CONTEXTS
from robot.running.namespace import Namespace
from robot.variables.scopes import VariableScopes
from robot.output import Output
from robot.running.model import TestSuite, TestCase as RunTest
from robot.result.model import TestSuite as ResultSuite, TestCase as ResTest
from robot.conf import Languages, RobotSettings

def setup_correct():
    """Set up context with CORRECT ordering."""
    variables = VariableScopes(RobotSettings())
    suite = TestSuite(name="Test")
    temp_dir = tempfile.mkdtemp(prefix="rf_exp_")
    settings = RobotSettings(outputdir=temp_dir, output=None, console='none')
    output = Output(settings)
    try: output.library_listeners.new_suite_scope()
    except: pass
    result_suite = ResultSuite(name=suite.name)
    namespace = Namespace(variables, result_suite, suite.resource, Languages())
    namespace.start_suite()
    namespace.variables.set_from_variable_section(suite.resource.variables)
    ctx = EXECUTION_CONTEXTS.start_suite(result_suite, namespace, output, dry_run=False)
    ctx.set_suite_variables(result_suite)
    namespace.handle_imports()
    namespace.variables.resolve_delayed()
    return ctx, namespace, variables

def test_multi_test_cycling():
    """Test: start_test_in_context double scope issue across multiple tests."""
    print("=== Test: Multi-test cycling scope accumulation ===")
    ctx, namespace, variables = setup_correct()
    
    # Simulate rf-mcp's start_test_in_context (line 764-765):
    #   namespace.start_test()
    #   ctx.start_test(run_test, res_test)
    
    print(f"  Base scopes (suite level): {len(variables._scopes)}")
    
    # Test 1 (rf-mcp style with double call)
    namespace.start_test()  # rf-mcp line 764
    run_test1 = RunTest(name="Test1")
    res_test1 = ResTest(name="Test1")
    ctx.start_test(run_test1, res_test1)  # rf-mcp line 765 → calls ns.start_test() again!
    print(f"  After start test 1: scopes={len(variables._scopes)} (should be 3)")
    
    # End test 1 (rf-mcp end_test_in_context, lines 802-803):
    #   ctx.end_test(res_test)     → calls namespace.end_test() internally
    #   namespace.end_test()       → ANOTHER end_test!
    ctx.end_test(res_test1)  # calls namespace.end_test internally
    namespace.end_test()  # rf-mcp line 803 → extra pop!
    print(f"  After end test 1:   scopes={len(variables._scopes)} (should be 2)")
    
    # Test 2 
    namespace.start_test()
    run_test2 = RunTest(name="Test2")
    res_test2 = ResTest(name="Test2")
    ctx.start_test(run_test2, res_test2)
    print(f"  After start test 2: scopes={len(variables._scopes)}")
    
    ctx.end_test(res_test2)
    namespace.end_test()
    print(f"  After end test 2:   scopes={len(variables._scopes)}")
    
    print(f"\n  Final scopes: {len(variables._scopes)}")
    if len(variables._scopes) < 2:
        print(f"  *** SCOPE UNDERFLOW! Global scope may be popped! ***")
    elif len(variables._scopes) > 2:
        print(f"  *** ZOMBIE SCOPES! ***")
    else:
        print(f"  Scopes balanced (but double push+pop is still wasteful)")
    
    EXECUTION_CONTEXTS.end_suite()

def test_correct_multi_test():
    """Show what correct multi-test looks like."""
    print("\n=== Test: Correct multi-test cycling ===")
    ctx, namespace, variables = setup_correct()
    
    print(f"  Base scopes: {len(variables._scopes)}")
    
    # Test 1 - ONLY ctx.start_test (which calls ns.start_test internally)
    run_test1 = RunTest(name="Test1")
    res_test1 = ResTest(name="Test1")
    ctx.start_test(run_test1, res_test1)
    print(f"  After start test 1: scopes={len(variables._scopes)}")
    
    from robot.libraries.BuiltIn import BuiltIn
    bi = BuiltIn()
    bi.run_keyword("Set Test Variable", "${T1VAR}", "test1_value")
    
    ctx.end_test(res_test1)
    print(f"  After end test 1:   scopes={len(variables._scopes)}")
    
    # Verify test variable is gone
    try:
        variables["${T1VAR}"]
        print(f"  T1VAR still visible (BAD)")
    except:
        print(f"  T1VAR properly cleaned")
    
    # Test 2
    run_test2 = RunTest(name="Test2")
    res_test2 = ResTest(name="Test2")
    ctx.start_test(run_test2, res_test2)
    print(f"  After start test 2: scopes={len(variables._scopes)}")
    
    bi.run_keyword("Set Test Variable", "${T2VAR}", "test2_value")
    
    ctx.end_test(res_test2)
    print(f"  After end test 2:   scopes={len(variables._scopes)}")
    
    try:
        variables["${T2VAR}"]
        print(f"  T2VAR still visible (BAD)")
    except:
        print(f"  T2VAR properly cleaned")
    
    print(f"\n  Final scopes: {len(variables._scopes)} (should be 2: global + suite)")
    
    EXECUTION_CONTEXTS.end_suite()

if __name__ == "__main__":
    test_multi_test_cycling()
    test_correct_multi_test()
