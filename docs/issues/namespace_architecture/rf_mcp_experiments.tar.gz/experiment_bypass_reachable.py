"""
Experiment 4: Is the direct method bypass actually reachable?
_execute_any_keyword_generic falls through to _try_execute_from_library
only if namespace.get_runner() raises a non-ExecutionStatus exception.
When does that happen?
"""
import sys, os, tempfile

from robot.running.context import EXECUTION_CONTEXTS
from robot.running.namespace import Namespace
from robot.variables.scopes import VariableScopes
from robot.output import Output
from robot.running.model import TestSuite, TestCase as RunTest, Keyword as RunKeyword
from robot.result.model import TestSuite as ResultSuite, TestCase as ResTest, Keyword as ResultKeyword
from robot.conf import Languages, RobotSettings
from robot.errors import ExecutionStatus, KeywordError

def setup():
    variables = VariableScopes(RobotSettings())
    suite = TestSuite(name="Test")
    temp_dir = tempfile.mkdtemp(prefix="rf_exp_")
    settings = RobotSettings(outputdir=temp_dir, output=None, console='none')
    output = Output(settings)
    try: output.library_listeners.new_suite_scope()
    except: pass
    result_suite = ResultSuite(name=suite.name)
    namespace = Namespace(variables, result_suite, suite.resource, Languages())
    namespace.start_suite()
    ctx = EXECUTION_CONTEXTS.start_suite(result_suite, namespace, output, dry_run=False)
    ctx.set_suite_variables(result_suite)
    namespace.handle_imports()
    namespace.import_library("Collections")
    namespace.start_test()
    run_test = RunTest(name="Test")
    res_test = ResTest(name="Test")
    ctx.start_test(run_test, res_test)
    return ctx, namespace, variables, res_test

print("=== Test: What errors does get_runner raise? ===")
ctx, namespace, variables, res_test = setup()

# Case 1: Non-existent keyword
print("\n1. Non-existent keyword:")
try:
    runner = namespace.get_runner("Totally Nonexistent Keyword")
    print(f"   Got runner: {type(runner).__name__}")
    # get_runner ALWAYS returns a runner (may be InvalidKeywordRunner)
    # Let's check
    print(f"   Runner keyword type: {type(runner.keyword).__name__}")
except Exception as e:
    print(f"   Exception: {type(e).__name__}: {e}")

# Case 2: What does InvalidKeyword runner do when run?
print("\n2. InvalidKeyword runner behavior:")
try:
    runner = namespace.get_runner("Totally Nonexistent Keyword")
    data_kw = RunKeyword(name="Totally Nonexistent Keyword", args=())
    res_kw = ResultKeyword(name="Totally Nonexistent Keyword")
    res_kw.parent = res_test
    result = runner.run(data_kw, res_kw, ctx)
except ExecutionStatus as e:
    print(f"   ExecutionStatus raised (as expected): {e}")
    print(f"   This IS caught by rf-mcp's isinstance check ✓")
except KeywordError as e:
    print(f"   KeywordError raised: {e}")
    print(f"   Is this ExecutionStatus? {isinstance(e, ExecutionStatus)}")
except Exception as e:
    print(f"   {type(e).__name__}: {e}")
    print(f"   Is this ExecutionStatus? {isinstance(e, ExecutionStatus)}")

# Case 3: What happens with runner.run() when args are wrong?
print("\n3. Wrong args for keyword:")
try:
    runner = namespace.get_runner("Should Be Equal")
    data_kw = RunKeyword(name="Should Be Equal", args=())  # Missing required args
    res_kw = ResultKeyword(name="Should Be Equal")
    res_kw.parent = res_test
    result = runner.run(data_kw, res_kw, ctx)
except ExecutionStatus as e:
    print(f"   ExecutionStatus: {type(e).__name__}")
    print(f"   rf-mcp catches this correctly ✓")
except Exception as e:
    print(f"   {type(e).__name__}: {e}")
    print(f"   Is ExecutionStatus? {isinstance(e, ExecutionStatus)}")

# Case 4: What about StatusReporter issues (no result parent)?
print("\n4. runner.run() without parent on result keyword:")
try:
    runner = namespace.get_runner("Log")
    data_kw = RunKeyword(name="Log", args=("hello",))
    res_kw = ResultKeyword(name="Log")
    # NO parent set - what happens?
    result = runner.run(data_kw, res_kw, ctx)
    print(f"   Works without parent: {result}")
except Exception as e:
    print(f"   {type(e).__name__}: {e}")
    print(f"   Is ExecutionStatus? {isinstance(e, ExecutionStatus)}")

EXECUTION_CONTEXTS.end_suite()

print("\n=== CONCLUSION ===")
print("get_runner() returns InvalidKeywordRunner for unknown keywords (not an exception).")
print("runner.run() raises ExecutionStatus for all failure modes,")
print("which rf-mcp correctly catches. The direct method bypass is only reachable")
print("if runner.run() raises a NON-ExecutionStatus exception, which is rare.")
print("However, it CAN happen if the result keyword has no parent (StatusReporter issue).")
