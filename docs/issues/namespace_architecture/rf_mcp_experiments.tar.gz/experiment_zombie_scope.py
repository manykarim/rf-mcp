"""
Experiment 7: Does the zombie scope (4 instead of 3) actually break anything?
Key question: does Set Test Variable propagate correctly with 4 scopes?
"""
import tempfile
from robot.running.context import EXECUTION_CONTEXTS
from robot.running.namespace import Namespace
from robot.variables.scopes import VariableScopes
from robot.output import Output
from robot.running.model import TestSuite, TestCase as RunTest
from robot.result.model import TestSuite as ResultSuite, TestCase as ResTest
from robot.conf import Languages, RobotSettings

def setup_rfmcp_style():
    """rf-mcp style: double start_test → 4 scopes."""
    variables = VariableScopes(RobotSettings())
    suite = TestSuite(name="Test")
    temp_dir = tempfile.mkdtemp(prefix="rf_exp_")
    settings = RobotSettings(outputdir=temp_dir, output=None, console='none')
    output = Output(settings)
    try: output.library_listeners.new_suite_scope()
    except: pass
    result_suite = ResultSuite(name=suite.name)
    namespace = Namespace(variables, result_suite, suite.resource, Languages())
    ctx = EXECUTION_CONTEXTS.start_suite(result_suite, namespace, output, dry_run=False)
    namespace.handle_imports()
    namespace.start_suite()
    namespace.start_test()  # extra test scope
    run_test = RunTest(name="Test")
    res_test = ResTest(name="Test")
    ctx.start_test(run_test, res_test)  # real test scope
    return ctx, namespace, variables, res_test

print("=== Zombie scope variable behavior ===")
ctx, namespace, variables, res_test = setup_rfmcp_style()
from robot.libraries.BuiltIn import BuiltIn
bi = BuiltIn()

print(f"Scope depth: {len(variables._scopes)} (4 = zombie present)")
print(f"Scope stack: global[0] → suite[1] → ZOMBIE_TEST[2] → test[3]")

# Test 1: Set Test Variable
bi.run_keyword("Set Test Variable", "${TV}", "test_val")
print(f"\nSet Test Variable $TV = test_val")
for i, scope in enumerate(variables._scopes):
    try:
        val = scope["${TV}"]
        print(f"  scope[{i}]: ${'{TV}'} = {val}")
    except:
        print(f"  scope[{i}]: ${'{TV}'} not present")

# Test 2: Set Suite Variable  
bi.run_keyword("Set Suite Variable", "${SV}", "suite_val")
print(f"\nSet Suite Variable $SV = suite_val")
for i, scope in enumerate(variables._scopes):
    try:
        val = scope["${SV}"]
        print(f"  scope[{i}]: ${'{SV}'} = {val}")
    except:
        print(f"  scope[{i}]: ${'{SV}'} not present")

# Test 3: User keyword variable scoping
# When a user keyword starts, RF copies the SUITE scope (not test scope)
# With zombie scope, the suite scope is variables._suite
print(f"\nUser keyword scope source:")
print(f"  variables._suite is scope[{variables._scopes.index(variables._suite) if variables._suite in variables._scopes else '?'}]")
print(f"  variables._test is scope[{variables._scopes.index(variables._test) if variables._test in variables._scopes else '?'}]")

# Simulate user keyword entry
namespace.start_user_keyword()
print(f"\nAfter user keyword start: {len(variables._scopes)} scopes")
print(f"  Keyword scope should copy from suite (scope[1])")
# Check: does the keyword scope have test variables?
try:
    kw_tv = variables.current["${TV}"]
    print(f"  Keyword scope has $TV: {kw_tv} (unexpected if copied from suite)")
except:
    print(f"  Keyword scope does NOT have $TV (correct - keywords copy from suite)")

# But does it have suite variables?
try:
    kw_sv = variables.current["${SV}"]
    print(f"  Keyword scope has $SV: {kw_sv}")
except:
    print(f"  Keyword scope does NOT have $SV")

namespace.end_user_keyword()

# Test 4: What about the zombie scope after end_test?
print(f"\n--- After end_test ---")
ctx.end_test(res_test)
namespace.end_test()  # rf-mcp also calls this
print(f"Scope depth after double end: {len(variables._scopes)}")

# Is test variable still accessible from zombie scope?
try:
    zombie_tv = variables["${TV}"]
    print(f"  $TV still accessible: {zombie_tv} (LEAKED from zombie scope!)")
except:
    print(f"  $TV properly cleaned")

# Is suite variable still ok?
try:
    sv = variables["${SV}"]
    print(f"  $SV still accessible: {sv}")
except:
    print(f"  $SV lost!")

EXECUTION_CONTEXTS.end_suite()
