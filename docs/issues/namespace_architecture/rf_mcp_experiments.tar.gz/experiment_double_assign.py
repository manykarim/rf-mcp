"""
Experiment 3: Is rf-mcp's variable assignment duplicated?
When runner.run() gets assign=("${var}",), does RF handle it,
making rf-mcp's _handle_variable_assignment redundant?
"""
import sys, os, tempfile

from robot.running.context import EXECUTION_CONTEXTS
from robot.running.namespace import Namespace
from robot.variables.scopes import VariableScopes
from robot.output import Output
from robot.running.model import TestSuite, TestCase as RunTest, Keyword as RunKeyword
from robot.result.model import TestSuite as ResultSuite, TestCase as ResTest, Keyword as ResultKeyword
from robot.conf import Languages, RobotSettings

def setup():
    variables = VariableScopes(RobotSettings())
    suite = TestSuite(name="Test")
    temp_dir = tempfile.mkdtemp(prefix="rf_exp_")
    settings = RobotSettings(outputdir=temp_dir, output=None, console='none')
    output = Output(settings)
    try: output.library_listeners.new_suite_scope()
    except: pass
    result_suite = ResultSuite(name=suite.name)
    namespace = Namespace(variables, result_suite, suite.resource, Languages())
    namespace.start_suite()
    ctx = EXECUTION_CONTEXTS.start_suite(result_suite, namespace, output, dry_run=False)
    ctx.set_suite_variables(result_suite)
    namespace.handle_imports()
    namespace.import_library("Collections")
    namespace.start_test()
    run_test = RunTest(name="Test")
    res_test = ResTest(name="Test")
    ctx.start_test(run_test, res_test)
    return ctx, namespace, variables, res_test

def test_runner_handles_assign():
    """Verify runner.run() does assignment when assign is set."""
    print("=== Test: Does runner.run() auto-assign? ===")
    ctx, namespace, variables, res_test = setup()
    
    try:
        runner = namespace.get_runner("Create List")
        
        # Case A: WITH assign on RunKeyword
        data_kw = RunKeyword(
            name="Create List", 
            args=("a", "b", "c"),
            assign=("${result_a}",)  # RF should auto-assign
        )
        res_kw = ResultKeyword(name="Create List")
        res_kw.parent = res_test
        
        ret = runner.run(data_kw, res_kw, ctx)
        
        try:
            auto_val = variables["${result_a}"]
            print(f"  WITH assign: ${{result_a}} = {auto_val}  (RF auto-assigned ✓)")
        except:
            print(f"  WITH assign: ${{result_a}} NOT found (RF did NOT auto-assign)")
        
        # Case B: WITHOUT assign on RunKeyword  
        data_kw2 = RunKeyword(
            name="Create List",
            args=("x", "y"),
            assign=()  # No assignment
        )
        res_kw2 = ResultKeyword(name="Create List")
        res_kw2.parent = res_test
        
        ret2 = runner.run(data_kw2, res_kw2, ctx)
        print(f"  WITHOUT assign: return value = {ret2}")
        
        # Manual assignment (what rf-mcp does on top)
        variables["${result_b}"] = ret2
        manual_val = variables["${result_b}"]
        print(f"  Manual assign after: ${{result_b}} = {manual_val}")
        
        # Case C: What happens if both RF auto-assign AND manual?
        runner3 = namespace.get_runner("Create List")
        data_kw3 = RunKeyword(
            name="Create List",
            args=("1", "2"),
            assign=("${result_c}",)
        )
        res_kw3 = ResultKeyword(name="Create List")
        res_kw3.parent = res_test
        
        ret3 = runner3.run(data_kw3, res_kw3, ctx)
        
        # Check RF assigned value
        auto_val3 = variables["${result_c}"]
        print(f"\n  DOUBLE ASSIGN TEST:")
        print(f"  After runner.run() with assign: ${{result_c}} = {auto_val3}")
        
        # Now manually overwrite (rf-mcp does this in _handle_variable_assignment)
        variables["${result_c}"] = "OVERWRITTEN"
        overwritten = variables["${result_c}"]
        print(f"  After manual overwrite: ${{result_c}} = {overwritten}")
        print(f"  => Double assignment causes overwrite (harmless but wasteful)")
        
    except Exception as e:
        print(f"  FAILED: {e}")
        import traceback; traceback.print_exc()
    finally:
        EXECUTION_CONTEXTS.end_suite()

def test_assign_scope_level():
    """Test: What scope level does runner.run() assign to?"""
    print("\n=== Test: Runner assign scope level ===")
    ctx, namespace, variables, res_test = setup()
    
    try:
        runner = namespace.get_runner("Create List")
        
        data_kw = RunKeyword(
            name="Create List",
            args=("a",),
            assign=("${scoped_var}",)
        )
        res_kw = ResultKeyword(name="Create List")
        res_kw.parent = res_test
        
        runner.run(data_kw, res_kw, ctx)
        
        # Check at which scope level the var exists
        val_current = variables.current.get("${scoped_var}")
        print(f"  Current scope has ${{scoped_var}}: {val_current}")
        
        # Check: is it at test level? (should be, since we're in a test)
        scope_count = len(variables._scopes)
        print(f"  Number of active scopes: {scope_count}")
        
        # RF's VariableAssignment assigns to the CURRENT scope
        # (which is the test scope after start_test)
        for i, scope in enumerate(variables._scopes):
            has = "${scoped_var}" in scope if hasattr(scope, '__contains__') else False
            try:
                has = scope.get("${scoped_var}") is not None
            except:
                has = False
            print(f"  Scope [{i}] has ${{scoped_var}}: {has}")
        
    except Exception as e:
        print(f"  FAILED: {e}")
        import traceback; traceback.print_exc()
    finally:
        EXECUTION_CONTEXTS.end_suite()


def test_rfmcp_builtin_import_timing():
    """Test: What happens when BuiltIn import is attempted before context exists?"""
    print("\n=== Test: BuiltIn import timing (rf-mcp bug) ===")
    
    variables = VariableScopes(RobotSettings())
    suite = TestSuite(name="Test")
    
    temp_dir = tempfile.mkdtemp(prefix="rf_exp_")
    result_suite = ResultSuite(name=suite.name)
    namespace = Namespace(variables, result_suite, suite.resource, Languages())
    
    # Try to import BuiltIn BEFORE context exists (rf-mcp does this)
    try:
        namespace.import_library("BuiltIn")
        print(f"  import_library('BuiltIn') before context: SUCCESS (unexpected)")
    except Exception as e:
        print(f"  import_library('BuiltIn') before context: FAILED ✓")
        print(f"    Error: {type(e).__name__}: {e}")
    
    # Now use handle_imports (internal _import_library) which ALSO needs context
    try:
        namespace.handle_imports()
        print(f"  handle_imports() before context: SUCCESS (unexpected)")
    except Exception as e:
        print(f"  handle_imports() before context: FAILED ✓")
        print(f"    Error: {type(e).__name__}: {e}")
    
    # Now push context and try again
    settings = RobotSettings(outputdir=temp_dir, output=None, console='none')
    output = Output(settings)
    try: output.library_listeners.new_suite_scope()
    except: pass
    
    ctx = EXECUTION_CONTEXTS.start_suite(result_suite, namespace, output, dry_run=False)
    
    # NOW import works
    try:
        namespace.import_library("BuiltIn")
        print(f"  import_library('BuiltIn') after context: SUCCESS ✓")
    except Exception as e:
        print(f"  import_library('BuiltIn') after context: FAILED - {e}")
    
    # Check: is BuiltIn available?
    libs = [lib.name for lib in namespace.libraries]
    print(f"  Libraries in namespace: {libs}")
    
    # Note: handle_imports() would import BuiltIn + Easter via _import_library
    # which doesn't call _current_owner_and_lineno. Let me check...
    EXECUTION_CONTEXTS.end_suite()
    
    # Fresh test with _import_library (internal path)
    print(f"\n  Testing _import_library (internal path):")
    variables2 = VariableScopes(RobotSettings())
    suite2 = TestSuite(name="Test2")
    result_suite2 = ResultSuite(name=suite2.name)
    namespace2 = Namespace(variables2, result_suite2, suite2.resource, Languages())
    
    # _import_library uses a different code path than import_library (public API)
    from robot.running.resourcemodel import Import
    imp = Import(Import.LIBRARY, "BuiltIn")
    try:
        namespace2._import_library(imp, notify=True)
        print(f"  _import_library before context: SUCCESS (no _current_owner_and_lineno needed)")
    except Exception as e:
        print(f"  _import_library before context: FAILED - {type(e).__name__}: {e}")
    
    libs2 = [lib.name for lib in namespace2.libraries]
    print(f"  Libraries: {libs2}")


if __name__ == "__main__":
    test_runner_handles_assign()
    test_assign_scope_level()
    test_rfmcp_builtin_import_timing()
