"""
Experiment 1: Does the ordering of start_suite / import / EXECUTION_CONTEXTS matter?
Compare rf-mcp's order vs RF-native order.
"""
import sys, os, tempfile, traceback

from robot.running.context import EXECUTION_CONTEXTS, _ExecutionContext
from robot.running.namespace import Namespace
from robot.variables.scopes import VariableScopes
from robot.output import Output
from robot.running.model import TestSuite, TestCase as RunTest
from robot.result.model import TestCase as ResTest
from robot.conf import Languages, RobotSettings

def rfmcp_order(label, libraries=None):
    """Replicate rf-mcp's create_context_for_session ordering."""
    libraries = libraries or []
    print(f"\n{'='*60}")
    print(f"TEST: {label}")
    print(f"{'='*60}")

    try:
        variables = VariableScopes(RobotSettings())
        
        # rf-mcp manually sets built-in variables
        for k, v in {"${True}": True, "${False}": False, "${None}": None}.items():
            variables[k] = v

        suite = TestSuite(name=f"MCP_Test")
        
        temp_dir = tempfile.mkdtemp(prefix="rf_exp_")
        settings = RobotSettings(outputdir=temp_dir, output=None, console='none')
        output = Output(settings)
        try:
            output.library_listeners.new_suite_scope()
        except Exception:
            pass
        variables["${OUTPUTDIR}"] = temp_dir

        namespace = Namespace(variables, suite, suite.resource, Languages())

        # rf-mcp imports BuiltIn BEFORE start_suite
        namespace.import_library("BuiltIn")
        print(f"  [1] Imported BuiltIn BEFORE start_suite")
        
        # rf-mcp pushes context BEFORE namespace.start_suite
        ctx = EXECUTION_CONTEXTS.start_suite(suite, namespace, output, dry_run=False)
        print(f"  [2] Pushed ExecutionContext BEFORE namespace.start_suite")

        # rf-mcp then calls start_suite + start_test
        namespace.start_suite()
        namespace.start_test()
        print(f"  [3] Called namespace.start_suite() + start_test()")
        
        # Start test in context
        run_test = RunTest(name="MCP_Test")
        res_test = ResTest(name="MCP_Test")
        ctx.start_test(run_test, res_test)
        print(f"  [4] Called ctx.start_test()")

        # Import user libraries
        for lib in libraries:
            try:
                namespace.import_library(lib)
                print(f"  [5] Imported {lib}")
            except Exception as e:
                print(f"  [5] FAILED to import {lib}: {e}")
        
        # Test keyword execution
        from robot.libraries.BuiltIn import BuiltIn
        bi = BuiltIn()
        result = bi.run_keyword("Evaluate", "40 + 2")
        print(f"  Evaluate 40+2 = {result} ✓")
        
        # Test variable scoping
        bi.run_keyword("Set Test Variable", "${MY_VAR}", "test_value")
        val = bi.get_variable_value("${MY_VAR}")
        print(f"  Set Test Variable + get = {val} ✓")
        
        # Check scope depth
        print(f"  Variable scope depth: {len(variables._scopes)}")
        print(f"  EXECUTION_CONTEXTS depth: {len(EXECUTION_CONTEXTS._contexts)}")
        
        print(f"  RESULT: PASS")
    except Exception as e:
        print(f"  RESULT: FAIL - {e}")
        traceback.print_exc()
    finally:
        # Clean up
        try:
            EXECUTION_CONTEXTS.end_suite()
        except:
            pass

def rf_native_order(label, libraries=None):
    """Replicate RF's actual SuiteRunner.start_suite ordering."""
    libraries = libraries or []
    print(f"\n{'='*60}")
    print(f"TEST: {label}")
    print(f"{'='*60}")
    
    try:
        variables = VariableScopes(RobotSettings())
        
        suite = TestSuite(name=f"Native_Test")
        
        temp_dir = tempfile.mkdtemp(prefix="rf_exp_")
        settings = RobotSettings(outputdir=temp_dir, output=None, console='none')
        output = Output(settings)
        try:
            output.library_listeners.new_suite_scope()
        except:
            pass

        from robot.result.model import TestSuite as ResultSuite
        result_suite = ResultSuite(name=suite.name, source=suite.source)
        
        # RF NATIVE ORDER:
        # 1. Create Namespace
        namespace = Namespace(variables, result_suite, suite.resource, Languages())
        print(f"  [1] Created Namespace")
        
        # 2. start_suite() on namespace (pushes suite variable scope)
        namespace.start_suite()
        print(f"  [2] Called namespace.start_suite()")
        
        # 3. Set from variable section
        namespace.variables.set_from_variable_section(suite.resource.variables)
        print(f"  [3] Set from variable section")
        
        # 4. Push execution context
        ctx = EXECUTION_CONTEXTS.start_suite(result_suite, namespace, output, dry_run=False)
        print(f"  [4] Pushed ExecutionContext")
        
        # 5. Set suite variables
        ctx.set_suite_variables(result_suite)
        print(f"  [5] Set suite variables")
        
        # 6. handle_imports (imports BuiltIn, Easter, then user libs)
        namespace.handle_imports()
        print(f"  [6] handle_imports() (BuiltIn + Easter)")
        
        # 7. Resolve delayed
        namespace.variables.resolve_delayed()
        print(f"  [7] resolve_delayed()")
        
        # Import user libraries
        for lib in libraries:
            try:
                namespace.import_library(lib)
                print(f"  [8] Imported {lib}")
            except Exception as e:
                print(f"  [8] FAILED to import {lib}: {e}")
        
        # Start test
        namespace.start_test()
        run_test = RunTest(name="Native_Test")
        res_test = ResTest(name="Native_Test")
        ctx.start_test(run_test, res_test)
        print(f"  [9] Started test (namespace + context)")
        
        # Test keyword execution
        from robot.libraries.BuiltIn import BuiltIn
        bi = BuiltIn()
        result = bi.run_keyword("Evaluate", "40 + 2")
        print(f"  Evaluate 40+2 = {result} ✓")
        
        # Test variable scoping
        bi.run_keyword("Set Test Variable", "${MY_VAR}", "test_value")
        val = bi.get_variable_value("${MY_VAR}")
        print(f"  Set Test Variable + get = {val} ✓")
        
        # Check scope depth
        print(f"  Variable scope depth: {len(variables._scopes)}")
        print(f"  EXECUTION_CONTEXTS depth: {len(EXECUTION_CONTEXTS._contexts)}")
        
        # Test: are ${SUITE_NAME} etc. available?
        suite_name = bi.get_variable_value("${SUITE_NAME}")
        print(f"  ${{SUITE_NAME}} = {suite_name} ✓")
        
        print(f"  RESULT: PASS")
    except Exception as e:
        print(f"  RESULT: FAIL - {e}")
        traceback.print_exc()
    finally:
        try:
            EXECUTION_CONTEXTS.end_suite()
        except:
            pass

if __name__ == "__main__":
    rfmcp_order("rf-mcp ordering (current)", libraries=["Collections"])
    rf_native_order("RF-native ordering (correct)", libraries=["Collections"])
