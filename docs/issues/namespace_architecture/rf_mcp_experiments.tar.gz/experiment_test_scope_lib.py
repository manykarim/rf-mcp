"""
Experiment 8: Does double end_test corrupt TEST-scoped library instances?
"""
import tempfile
from robot.running.context import EXECUTION_CONTEXTS
from robot.running.namespace import Namespace
from robot.variables.scopes import VariableScopes
from robot.output import Output
from robot.running.model import TestSuite, TestCase as RunTest
from robot.result.model import TestSuite as ResultSuite, TestCase as ResTest
from robot.conf import Languages, RobotSettings
from robot.running.libraryscopes import TestScopeManager

print("=== Experiment: TEST-scope library double end_test ===\n")

# Check what end_test does to a TestScopeManager
print("TestScopeManager.end_test source:")
import inspect
print(inspect.getsource(TestScopeManager.end_test))

print("\nTestScopeManager.start_test source:")
print(inspect.getsource(TestScopeManager.start_test))

# Now simulate
variables = VariableScopes(RobotSettings())
suite = TestSuite(name="Test")
temp_dir = tempfile.mkdtemp(prefix="rf_exp_")
settings = RobotSettings(outputdir=temp_dir, output=None, console='none')
output = Output(settings)
try: output.library_listeners.new_suite_scope()
except: pass
result_suite = ResultSuite(name=suite.name)
namespace = Namespace(variables, result_suite, suite.resource, Languages())

# Push context first (to allow import_library)
ctx = EXECUTION_CONTEXTS.start_suite(result_suite, namespace, output, dry_run=False)
namespace.handle_imports()  # BuiltIn + Easter (both GLOBAL scope)
namespace.start_suite()

# Check: BuiltIn is GLOBAL scope, so end_test is a no-op
for lib in namespace.libraries:
    print(f"Library: {lib.name}, scope: {lib.scope.name}, "
          f"scope_manager: {type(lib.scope_manager).__name__}")
    if hasattr(lib.scope_manager, 'instance_cache'):
        print(f"  instance_cache depth: {len(lib.scope_manager.instance_cache)}")

# Now do rf-mcp double start/end test
print("\n--- rf-mcp double start_test ---")
namespace.start_test()  # extra
run_test = RunTest(name="T1")
res_test = ResTest(name="T1")
ctx.start_test(run_test, res_test)  # real (calls ns.start_test again)

for lib in namespace.libraries:
    if hasattr(lib.scope_manager, 'instance_cache'):
        print(f"  {lib.name} instance_cache after double start: {len(lib.scope_manager.instance_cache)}")

print("\n--- rf-mcp double end_test ---")
ctx.end_test(res_test)  # calls ns.end_test
namespace.end_test()     # EXTRA call

for lib in namespace.libraries:
    if hasattr(lib.scope_manager, 'instance_cache'):
        print(f"  {lib.name} instance_cache after double end: {len(lib.scope_manager.instance_cache)}")

# With only GLOBAL-scoped libraries (BuiltIn, Easter), end_test is a no-op.
# The bug only manifests with TEST-scoped libraries (e.g., custom libs).
# However, no standard RF libraries use TEST scope by default.
print("\nConclusion: Double end_test is safe for GLOBAL and SUITE scoped libs (most common).")
print("It WOULD corrupt instance_cache for TEST-scoped libraries (rare).")

EXECUTION_CONTEXTS.end_suite()
